class Product {
  final String id;
  final String name;
  final String brand;
  final String category;
  final double price;
  final double rating;
  final String imageUrl;
  final String description;
  final List<String> specifications;
  final List<Review> reviews;

  Product({
    required this.id,
    required this.name,
    required this.brand,
    required this.category,
    required this.price,
    required this.rating,
    required this.imageUrl,
    required this.description,
    required this.specifications,
    required this.reviews,
  });

  static List<Product> get dummyProducts => [
    Product(
      id: '1',
      name: 'MacBook Pro M3',
      brand: 'Apple',
      category: 'Creative',
      price: 1999.99,
      rating: 4.9,
      imageUrl: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=1000&auto=format&fit=crop',
      description: 'The most powerful MacBook ever. With the M3 chip, it delivers incredible performance and battery life.',
      specifications: ['M3 Chip', '16GB RAM', '512GB SSD', '14-inch Liquid Retina XDR'],
      reviews: [
        Review(userId: 'u1', userName: 'Alice', rating: 5.0, comment: 'Amazing performance!', date: DateTime.now()),
      ],
    ),
    Product(
      id: '2',
      name: 'Dell XPS 15',
      brand: 'Dell',
      category: 'Business',
      price: 1499.99,
      rating: 4.8,
      imageUrl: 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?q=80&w=1000&auto=format&fit=crop',
      description: 'The ultimate power machine for creators and professionals.',
      specifications: ['Intel Core i7', '16GB DDR5', '512GB NVMe SSD', '15.6" 4K OLED'],
      reviews: [],
    ),
    Product(
      id: '3',
      name: 'HP Spectre x360',
      brand: 'HP',
      category: 'Student',
      price: 1299.99,
      rating: 4.7,
      imageUrl: 'https://images.unsplash.com/photo-1544006659-f0b21f04cb1d?q=80&w=1000&auto=format&fit=crop',
      description: 'A versatile 2-in-1 laptop with a stunning design and great performance.',
      specifications: ['Intel Core i7', '16GB RAM', '1TB SSD', '13.5" Touchscreen'],
      reviews: [],
    ),
    Product(
      id: '4',
      name: 'Razer Blade 16',
      brand: 'Razer',
      category: 'Gaming',
      price: 2999.99,
      rating: 4.9,
      imageUrl: 'https://images.unsplash.com/photo-1525547718571-a7144c1ff391?q=80&w=1000&auto=format&fit=crop',
      description: 'The ultimate gaming laptop with a stunning 16-inch display and top-tier performance.',
      specifications: ['Intel Core i9', '32GB RAM', '1TB SSD', 'RTX 4090'],
      reviews: [],
    ),
    Product(
      id: '5',
      name: 'ASUS ROG Zephyrus G14',
      brand: 'ASUS',
      category: 'Gaming',
      price: 1599.99,
      rating: 4.8,
      imageUrl: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?q=80&w=1000&auto=format&fit=crop',
      description: 'A compact gaming powerhouse with a unique design and incredible performance.',
      specifications: ['AMD Ryzen 9', '16GB RAM', '1TB SSD', 'RTX 4060'],
      reviews: [],
    ),
    Product(
      id: '6',
      name: 'Lenovo ThinkPad X1 Carbon',
      brand: 'Lenovo',
      category: 'Business',
      price: 1699.99,
      rating: 4.7,
      imageUrl: 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?q=80&w=1000&auto=format&fit=crop',
      description: 'The legendary business laptop, known for its durability and excellent keyboard.',
      specifications: ['Intel Core i7', '16GB RAM', '512GB SSD', '14-inch IPS'],
      reviews: [],
    ),
  ];
}

class Review {
  final String userId;
  final String userName;
  final double rating;
  final String comment;
  final DateTime date;

  Review({
    required this.userId,
    required this.userName,
    required this.rating,
    required this.comment,
    required this.date,
  });
}
