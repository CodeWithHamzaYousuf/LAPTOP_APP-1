import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        children: [
          _buildSectionHeader('Account'),
          _buildSettingTile('Edit Profile', Icons.person_outline, onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Edit Profile coming soon')));
          }),
          _buildSettingTile('Change Password', Icons.lock_outline, onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Change Password coming soon')));
          }),
          _buildSettingTile('Privacy Settings', Icons.privacy_tip, onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Privacy Settings coming soon')));
          }),

          _buildSectionHeader('Notifications'),
          SwitchListTile(
            title: const Text('Push Notifications'),
            value: true,
            onChanged: (val) {},
            activeColor: AppTheme.primaryColor,
          ),
          SwitchListTile(
            title: const Text('Email Updates'),
            value: false,
            onChanged: (val) {},
            activeColor: AppTheme.primaryColor,
          ),
          _buildSectionHeader('App'),
          _buildSettingTile('Language', Icons.language, trailing: 'English'),
          _buildSettingTile('Currency', Icons.attach_money, trailing: 'USD'),
          _buildSettingTile('About Us', Icons.info_outline),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title,
        style: const TextStyle(
          color: AppTheme.primaryColor,
          fontWeight: FontWeight.bold,
          fontSize: 14,
        ),
      ),
    );
  }

  Widget _buildSettingTile(String title, IconData icon, {String? trailing, VoidCallback? onTap}) {
    return ListTile(
      leading: Icon(icon, color: Colors.grey[600]),
      title: Text(title),
      trailing: trailing != null 
        ? Text(trailing, style: const TextStyle(color: Colors.grey))
        : const Icon(Icons.chevron_right, size: 20),
      onTap: onTap ?? () {},
    );
  }
}
