import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';
import 'order_history_screen.dart';
import 'settings_screen.dart';
import 'support_screen.dart';
import 'shipping_addresses_screen.dart';
import 'payment_methods_screen.dart';
import 'auth/login_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _avatarCtrl;
  late Animation<double> _avatarPulse;

  static const pink = Color(0xFFFF5F9E);
  static const blue = Color(0xFF5B8CFF);
  static const cyan = Color(0xFF2CE1E8);
  static const ink = Color(0xFF1C1C28);
  static const bg = Color(0xFFF7F8FA);

  @override
  void initState() {
    super.initState();
    _avatarCtrl =
        AnimationController(vsync: this, duration: const Duration(seconds: 3))
          ..repeat(reverse: true);

    _avatarPulse =
        Tween<double>(begin: 1, end: 1.06).animate(CurvedAnimation(
      parent: _avatarCtrl,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _avatarCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final user = authProvider.user;

    if (!authProvider.isAuthenticated) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('Please login to view your profile'),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                  );
                },
                child: const Text('Login'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: bg,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          _heroAppBar(context),
          SliverToBoxAdapter(
            child: Column(
              children: [
                const SizedBox(height: 28),
                _profileCard(user!.name, user.email),
                const SizedBox(height: 36),
                _actionSection(context),
                const SizedBox(height: 140),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================= HERO APP BAR =================
  SliverAppBar _heroAppBar(BuildContext context) {
    return SliverAppBar(
      expandedHeight: 180,
      elevation: 0,
      pinned: true,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [pink, blue, cyan],
          ),
        ),
        child: const FlexibleSpaceBar(
          centerTitle: true,
          title: Text(
            'Profile',
            style: TextStyle(
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }

  // ================= PROFILE CARD =================
  Widget _profileCard(String name, String email) {
    return AnimatedBuilder(
      animation: _avatarPulse,
      builder: (_, child) =>
          Transform.scale(scale: _avatarPulse.value, child: child),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.fromLTRB(20, 30, 20, 26),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: LinearGradient(
            colors: [
              Colors.white.withOpacity(.95),
              Colors.white.withOpacity(.85),
            ],
          ),
          boxShadow: [
            BoxShadow(
              color: pink.withOpacity(.25),
              blurRadius: 30,
              offset: const Offset(0, 16),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(5),
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [pink, blue]),
              ),
              child: const CircleAvatar(
                radius: 46,
                backgroundColor: ink,
                child: Icon(Icons.person, size: 52, color: Colors.white),
              ),
            ),
            const SizedBox(height: 18),
            Text(
              name,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w900,
                color: ink,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              email,
              style: const TextStyle(color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }

  // ================= ACTIONS =================
  Widget _actionSection(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(26),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.06),
            blurRadius: 20,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        children: [
          _item(
            icon: Icons.history,
            label: 'Order History',
            onTap: () => _nav(context, const OrderHistoryScreen()),
          ),
          _divider(),
          _item(
            icon: Icons.location_on_outlined,
            label: 'Shipping Addresses',
            onTap: () => _nav(context, const ShippingAddressesScreen()),
          ),
          _divider(),
          _item(
            icon: Icons.payment,
            label: 'Payment Methods',
            onTap: () => _nav(context, const PaymentMethodsScreen()),
          ),
          _divider(),
          _item(
            icon: Icons.settings_outlined,
            label: 'Settings',
            onTap: () => _nav(context, const SettingsScreen()),
          ),
          _divider(),
          _item(
            icon: Icons.help_outline,
            label: 'Support',
            onTap: () => _nav(context, const SupportScreen()),
          ),
          _divider(),
          _item(
            icon: Icons.logout,
            label: 'Logout',
            danger: true,
            onTap: () {
              context.read<AuthProvider>().logout();
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
                (route) => false,
              );
            },
          ),
        ],
      ),
    );
  }

  // ================= ITEM =================
  Widget _item({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool danger = false,
  }) {
    return InkWell(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: ListTile(
          leading: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: danger
                  ? Colors.red.withOpacity(.12)
                  : pink.withOpacity(.12),
            ),
            child: Icon(icon,
                color: danger ? Colors.red : pink),
          ),
          title: Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: danger ? Colors.red : ink,
            ),
          ),
          trailing: const Icon(Icons.chevron_right, color: Colors.grey),
        ),
      ),
    );
  }

  Widget _divider() {
    return const Padding(
      padding: EdgeInsets.only(left: 72),
      child: Divider(height: 1),
    );
  }

  void _nav(BuildContext context, Widget screen) {
    Navigator.push(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 400),
        pageBuilder: (_, animation, __) => screen,
        transitionsBuilder: (_, animation, __, child) {
          return SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(1, 0),
              end: Offset.zero,
            ).animate(
              CurvedAnimation(
                parent: animation,
                curve: Curves.easeOutExpo,
              ),
            ),
            child: FadeTransition(opacity: animation, child: child),
          );
        },
      ),
    );
  }
}
