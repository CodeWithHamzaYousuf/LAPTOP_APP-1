import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'checkout_screen.dart';
import '../providers/cart_provider.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  static const pink = Color(0xFFFF5F9E);
  static const blue = Color(0xFF5B8CFF);
  static const cyan = Color(0xFF2CE1E8);
  static const ink = Color(0xFF1C1C28);
  static const bg = Color(0xFFF7F8FA);

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();

    return Scaffold(
      backgroundColor: bg,
      body: Column(
        children: [
          _heroAppBar(context),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 24, 16, 160),
              physics: const BouncingScrollPhysics(),
              itemCount: cart.items.length,
              itemBuilder: (_, i) => _cartItem(cart.items[i]),
            ),
          ),
          _glassCheckoutBar(context, cart),
        ],
      ),
    );
  }

  Widget _heroAppBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 52, 20, 26),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [pink, blue, cyan],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.vertical(
          bottom: Radius.circular(34),
        ),
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          const Text(
            'My Cart',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
          const Spacer(),
          const Icon(Icons.shopping_cart_rounded, color: Colors.white),
        ],
      ),
    );
  }
Widget _cartItem(CartItem item) {
  return Consumer<CartProvider>(
    builder: (context, cart, _) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 450),
      curve: Curves.easeOutExpo,
      builder: (_, value, child) => Opacity(
        opacity: value,
        child: Transform.translate(
          offset: Offset(0, 40 * (1 - value)),
          child: child,
        ),
      ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 20),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: LinearGradient(
            colors: [Colors.white.withOpacity(.95), Colors.white.withOpacity(.8)],
          ),
          boxShadow: [
            BoxShadow(
              color: CartScreen.pink.withOpacity(.18),
              blurRadius: 24,
              offset: const Offset(0, 14),
            ),
          ],
        ),
        child: Row(
          children: [
            _productImage(),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.product.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: CartScreen.ink)),
                  const SizedBox(height: 6),
                  Text('\$${item.product.price}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: CartScreen.pink)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _qtyBtn(Icons.remove, () => cart.decreaseQty(item)),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        child: Text(item.quantity.toString(), style: const TextStyle(fontWeight: FontWeight.w700)),
                      ),
                      _qtyBtn(Icons.add, () => cart.increaseQty(item)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}



  Widget _productImage() {
    return Container(
      width: 82,
      height: 82,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(colors: [pink.withOpacity(.15), blue.withOpacity(.18)]),
      ),
      child: const Icon(Icons.laptop_mac_rounded, size: 42, color: pink),
    );
  }

  Widget _qtyBtn(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          gradient: LinearGradient(colors: [pink.withOpacity(.2), blue.withOpacity(.25)]),
        ),
        child: Icon(icon, size: 18, color: pink),
      ),
    );
  }

  Widget _glassCheckoutBar(BuildContext context, CartProvider cart) {
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(34)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
        child: Container(
          padding: const EdgeInsets.fromLTRB(22, 20, 22, 30),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(.75),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(34)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _summaryRow('Subtotal', '\$${cart.subtotal.toStringAsFixed(2)}'),
              _summaryRow('Shipping', 'Free'),
              const Divider(height: 30),
              _summaryRow('Total', '\$${cart.subtotal.toStringAsFixed(2)}', isTotal: true),
              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    elevation: 10,
                    backgroundColor: Colors.transparent,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    padding: EdgeInsets.zero,
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const CheckoutScreen()),
                    );
                  },
                  child: Ink(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(colors: [pink, blue]),
                      borderRadius: BorderRadius.all(Radius.circular(18)),
                    ),
                    child: const Center(
                      child: Text(
                        'Secure Checkout',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _summaryRow(String label, String value, {bool isTotal = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: isTotal ? 18 : 14, fontWeight: isTotal ? FontWeight.w800 : FontWeight.w600)),
          Text(value, style: TextStyle(fontSize: isTotal ? 18 : 14, fontWeight: isTotal ? FontWeight.w900 : FontWeight.w700, color: isTotal ? pink : ink)),
        ],
      ),
    );
  }
}
  