import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Support'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'How can we help you?',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Our team is here to assist you with any questions or issues.',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 32),
            _buildSupportCard(
              Icons.chat_outlined,
              'Live Chat',
              'Chat with our support team in real-time.',
              () {},
            ),
            _buildSupportCard(
              Icons.email_outlined,
              'Email Support',
              'Send us an email and we\'ll get back to you within 24 hours.',
              () {},
            ),
            _buildSupportCard(
              Icons.phone_outlined,
              'Call Us',
              'Available Mon-Fri, 9am - 6pm.',
              () {},
            ),
            _buildSupportCard(
              Icons.question_answer_outlined,
              'FAQs',
              'Find answers to commonly asked questions.',
              () {},
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSupportCard(IconData icon, String title, String subtitle, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppTheme.primaryColor.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: AppTheme.primaryColor),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
        onTap: onTap,
      ),
    );
  }
}
