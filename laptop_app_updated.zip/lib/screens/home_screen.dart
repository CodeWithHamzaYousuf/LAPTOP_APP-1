import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'auth/login_screen.dart';

import '../models/product.dart';
import '../widgets/product_card.dart';
import '../providers/cart_provider.dart';

import 'product_list_screen.dart';
import 'wishlist_screen.dart';
import 'profile_screen.dart';
import 'cart_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final List<Widget> _screens = const [
    HomeContent(),
    ProductListScreen(),
    WishlistScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    if (!authProvider.isAuthenticated) {
      return const LoginScreen();
    }
    return Scaffold(
      extendBody: true,
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 550),
        switchInCurve: Curves.easeOutExpo,
        transitionBuilder: (child, animation) {
          return FadeTransition(
            opacity: animation,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.08, 0),
                end: Offset.zero,
              ).animate(animation),
              child: child,
            ),
          );
        },
        child: _screens[_selectedIndex],
      ),
      bottomNavigationBar: _glassNav(),
    );
  }

  // ================= BOTTOM NAV =================
  Widget _glassNav() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(36),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 28, sigmaY: 28),
          child: Container(
            height: 78,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(36),
              color: Colors.white.withOpacity(.75),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.15),
                  blurRadius: 30,
                  offset: const Offset(0, 14),
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _navItem(Icons.home_rounded, 'Home', 0),
                _navItem(Icons.laptop_mac_rounded, 'Shop', 1),
                _navItem(Icons.favorite_rounded, 'Wishlist', 2),
                _navItem(Icons.person_rounded, 'Profile', 3),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _navItem(IconData icon, String label, int index) {
    final active = _selectedIndex == index;

    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        setState(() => _selectedIndex = index);
      },
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 1, end: active ? 1.12 : 1),
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOutBack,
        builder: (_, scale, child) =>
            Transform.scale(scale: scale, child: child),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOutExpo,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: active
                ? const LinearGradient(
                    colors: [Color(0xFFFF5F9E), Color(0xFF5B8CFF)],
                  )
                : null,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon,
                  size: 26,
                  color: active ? Colors.white : Colors.black54),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: active ? Colors.white : Colors.black54,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================================
// ============================== HOME CONTENT ================================
// ============================================================================

class HomeContent extends StatefulWidget {
  const HomeContent({super.key});

  @override
  State<HomeContent> createState() => _HomeContentState();
}

class _HomeContentState extends State<HomeContent>
    with SingleTickerProviderStateMixin {
  late AnimationController _heroController;
  late Animation<double> _heroFloat;

  int selectedCategory = 0;
  final List<String> categories = ['All', 'Gaming', 'Business', 'Student', 'Creative'];

  @override
  void initState() {
    super.initState();
    _heroController =
        AnimationController(vsync: this, duration: const Duration(seconds: 4))
          ..repeat(reverse: true);

    _heroFloat = Tween<double>(begin: 0, end: 14).animate(
      CurvedAnimation(parent: _heroController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _heroController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final allProducts = Product.dummyProducts;
    final filteredProducts = selectedCategory == 0
        ? allProducts
        : allProducts.where((p) => p.category == categories[selectedCategory]).toList();

    final cart = context.watch<CartProvider>();

    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        _appBar(cart),
        SliverToBoxAdapter(child: _search()),
        SliverToBoxAdapter(child: _hero()),
        SliverToBoxAdapter(child: _section('Categories')),
        SliverToBoxAdapter(child: _categories()),
        SliverToBoxAdapter(child: _section('Featured')),
        _animatedGrid(filteredProducts),
        const SliverToBoxAdapter(child: SizedBox(height: 140)),
      ],
    );
  }

  // ================= APP BAR =================
  SliverAppBar _appBar(CartProvider cart) {
    return SliverAppBar(
      floating: true,
      elevation: 0,
      backgroundColor: Colors.transparent,
      title: const Text(
        'Laptop Harbor',
        style: TextStyle(fontWeight: FontWeight.w900),
      ),
      actions: [
        Stack(
          children: [
            IconButton(
              icon: const Icon(Icons.shopping_cart_outlined),
              onPressed: () {
                HapticFeedback.mediumImpact();
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const CartScreen()),
                );
              },
            ),
            if (cart.totalItems > 0)
              Positioned(
                right: 8,
                top: 8,
                child: Container(
                  height: 16,
                  width: 16,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFFFF4D6D),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    cart.totalItems.toString(),
                    style: const TextStyle(fontSize: 10, color: Colors.white),
                  ),
                ),
              )
          ],
        )
      ],
    );
  }

  // ================= SEARCH =================
  Widget _search() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.blue.withOpacity(0.08),
              blurRadius: 22,
            ),
          ],
        ),
        child: const TextField(
          decoration: InputDecoration(
            hintText: 'Search high-performance laptops',
            prefixIcon: Icon(Icons.search),
            border: InputBorder.none,
          ),
        ),
      ),
    );
  }

  // ================= HERO =================
  Widget _hero() {
    return AnimatedBuilder(
      animation: _heroFloat,
      builder: (_, child) => Transform.translate(
        offset: Offset(0, -_heroFloat.value),
        child: child,
      ),
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 16, 16, 26),
        padding: const EdgeInsets.all(30),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(36),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFFFF5F9E),
              Color(0xFF5B8CFF),
              Color(0xFF2CE1E8),
            ],
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.pink.withOpacity(.4),
              blurRadius: 40,
              offset: const Offset(0, 18),
            ),
          ],
        ),
        child: const Text(
          'Next-Gen Laptops ⚡\nBuilt for Power',
          style: TextStyle(
            color: Colors.white,
            fontSize: 26,
            fontWeight: FontWeight.w900,
            height: 1.2,
          ),
        ),
      ),
    );
  }

  // ================= SECTION =================
  Widget _section(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }

  // ================= CATEGORIES =================
  Widget _categories() {
    return SizedBox(
      height: 64,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: categories.length,
        itemBuilder: (_, i) {
          final active = selectedCategory == i;

          return GestureDetector(
            onTap: () => setState(() => selectedCategory = i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 350),
              curve: Curves.easeOutBack,
              margin: const EdgeInsets.only(right: 14),
              padding:
                  const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
              decoration: BoxDecoration(
                gradient: active
                    ? const LinearGradient(
                        colors: [
                          Color(0xFF36D1DC),
                          Color(0xFF5B86E5),
                        ],
                      )
                    : null,
                color: active ? null : Colors.white,
                borderRadius: BorderRadius.circular(18),
                boxShadow: active
                    ? [
                        BoxShadow(
                          color: Colors.blue.withOpacity(0.35),
                          blurRadius: 20,
                        )
                      ]
                    : [],
              ),
              child: Text(
                categories[i],
                style: TextStyle(
                  color: active ? Colors.white : Colors.black54,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ================= GRID =================
  Widget _animatedGrid(List<Product> products) {
    return SliverPadding(
      padding: const EdgeInsets.all(16),
      sliver: SliverGrid(
        delegate: SliverChildBuilderDelegate(
          (_, i) => TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: Duration(milliseconds: 320 + (i * 90)),
            curve: Curves.easeOut,
            builder: (_, value, child) => Opacity(
              opacity: value,
              child: Transform.translate(
                offset: Offset(0, 30 * (1 - value)),
                child: child,
              ),
            ),
            child: Transform.scale(
              scale: 0.92,
              child: ProductCard(product: products[i]),
            ),
          ),
          childCount: products.length,
        ),
        gridDelegate:
            const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 0.72,
        ),
      ),
    );
  }
}
