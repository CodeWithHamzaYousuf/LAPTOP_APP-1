import 'package:flutter/material.dart';
import '../models/user.dart';

class AuthProvider with ChangeNotifier {
  User? _user;

  User? get user => _user;
  bool get isAuthenticated => _user != null;

  void login(String email, String password) {
    // Mock login logic
    _user = User(
      id: '1',
      name: 'John Doe',
      email: email,
    );
    notifyListeners();
  }

  void register(String name, String email, String password) {
    // Mock registration logic
    _user = User(
      id: '1',
      name: name,
      email: email,
    );
    notifyListeners();
  }

  void logout() {
    _user = null;
    notifyListeners();
  }

  void updateProfile({String? name, String? email}) {
    if (_user != null) {
      _user = User(
        id: _user!.id,
        name: name ?? _user!.name,
        email: email ?? _user!.email,
        profileImageUrl: _user!.profileImageUrl,
      );
      notifyListeners();
    }
  }
}
